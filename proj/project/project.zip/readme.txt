Para ver a aplica��o:
- execute o miniweb.exe
- No Google Chrome abrir http://10.0.75.1:8000

Usu�rio e senha:
- User: uerj
- Senha: 123456